import React from'react';import{createRoot}from'react-dom/client';import{HashRouter}from'react-router-dom';import App from'./App.jsx';import'leaflet/dist/leaflet.css';import'./styles/global.css';
createRoot(document.getElementById('root')).render(<React.StrictMode><HashRouter><App/></HashRouter></React.StrictMode>);
if('serviceWorker'in navigator&&import.meta.env.PROD)window.addEventListener('load',()=>navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch(()=>{}));
