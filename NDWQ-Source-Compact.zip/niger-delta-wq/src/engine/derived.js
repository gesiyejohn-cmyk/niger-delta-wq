const round = (value, places = 2) => {
  const factor = 10 ** places;
  return Math.round(value * factor) / factor;
};

export function computeDerived(sample) {
  const result = {};
  const { ca, mg, na, k, hco3, co3, cl, so4 } = sample;

  if (ca != null && mg != null) {
    result.totalHardness = round(ca * 2.497 + mg * 4.118);
    result.hardnessClass = result.totalHardness < 60 ? 'Soft'
      : result.totalHardness < 120 ? 'Moderately hard'
      : result.totalHardness < 180 ? 'Hard' : 'Very hard';
  }

  if (na != null && ca != null && mg != null) {
    const sodiumMeq = na / 22.99;
    const calciumMeq = ca / 20.04;
    const magnesiumMeq = mg / 12.15;
    const denominator = Math.sqrt((calciumMeq + magnesiumMeq) / 2);
    if (denominator > 0) {
      result.sar = round(sodiumMeq / denominator);
      result.sarClass = result.sar < 10 ? 'Excellent'
        : result.sar < 18 ? 'Good'
        : result.sar < 26 ? 'Doubtful' : 'Unsuitable';
    } else {
      result.sar = null;
      result.sarNote = 'SAR cannot be calculated because calcium and magnesium are both zero.';
    }
  }

  if ([na, k, ca, mg].every(value => value != null)) {
    const totalCations = na / 22.99 + k / 39.10 + ca / 20.04 + mg / 12.15;
    result.naPercent = totalCations > 0 ? round((na / 22.99) / totalCations * 100) : null;
  }

  // Carbonate is required as a measured value. It is not silently assumed to be zero.
  if ([ca, mg, na, k, hco3, co3, cl, so4].every(value => value != null)) {
    const cations = ca / 20.04 + mg / 12.15 + na / 22.99 + k / 39.10;
    const anions = hco3 / 61.02 + co3 / 30 + cl / 35.45 + so4 / 48.03;
    const denominator = cations + anions;
    if (denominator > 0) {
      result.chargeBalanceError = round((cations - anions) / denominator * 100, 1);
      result.chargeBalanceOK = Math.abs(result.chargeBalanceError) <= 10;
    } else {
      result.chargeBalanceNote = 'Charge balance cannot be calculated because the total ionic concentration is zero.';
    }
  } else {
    result.chargeBalanceNote = 'Charge balance error requires measured major cations and anions, including carbonate. Missing ions are not assumed to be zero.';
  }

  return result;
}
