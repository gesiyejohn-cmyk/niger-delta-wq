import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getSample } from '../storage/samples.js';
import { getDB } from '../storage/db.js';
import { PARAMETER_REGISTRY } from '../engine/parameters.js';
import { Status } from './Dashboard.jsx';

export default function SampleDetail() {
  const { id } = useParams();
  const [sample, setSample] = useState(null);
  const [overrides, setOverrides] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const [record, db] = await Promise.all([getSample(id), getDB()]);
        const setting = await db.get('settings', 'guidelineOverrides');
        if (active) {
          setSample(record || null);
          setOverrides(setting?.value || {});
          if (!record) setError('This sample record could not be found.');
        }
      } catch (e) {
        if (active) setError(e.message || 'Could not load sample.');
      }
    })();
    return () => { active = false; };
  }, [id]);

  if (error && !sample) return <div className="page"><p className="warn">{error}</p><Link to="/">Back to dashboard</Link></div>;
  if (!sample) return <div className="page"><p>Loading sample…</p><Link to="/">Back</Link></div>;

  const guideline = (parameterId, standard) => {
    const base = PARAMETER_REGISTRY[parameterId]?.[standard];
    const override = overrides?.[parameterId]?.[standard];
    if (!base && !override) return null;
    const merged = { ...(base || {}) };
    for (const bound of ['min', 'max']) if (override?.[bound] != null) merged[bound] = override[bound];
    return merged;
  };
  const check = (parameterId, canonical, standard) => {
    const guide = guideline(parameterId, standard);
    if (!guide || canonical == null) return 'Not assessed';
    if (guide.min != null && canonical < guide.min) return 'Below minimum';
    if (guide.max != null && canonical > guide.max) return 'Exceeds maximum';
    return 'Within configured range';
  };

  return <div className="page">
    <div className="page-header"><div><p className="eyebrow">SAMPLE RECORD</p><h1>{sample.sampleCode || 'Uncoded sample'}</h1><p className="muted">{sample.stationName || 'Unnamed station'} · {sample.collectionDate || 'No date'}</p></div><div className="actions"><Link className="button primary" to={`/edit/${sample.id}`}>Edit sample</Link><Link className="button" to="/">All samples</Link></div></div>
    <div className="stat-grid">
      <div className="stat-card"><div><small>WHO configured-objective WQI</small><strong>{sample.wqi?.who?.wqi ?? '—'}</strong><Status value={sample.wqi?.who?.status}/></div></div>
      <div className="stat-card"><div><small>SON configured-objective WQI</small><strong>{sample.wqi?.son?.wqi ?? '—'}</strong><Status value={sample.wqi?.son?.status}/></div></div>
      <div className="stat-card"><div><small>Groundwater vulnerability</small><strong>{sample.vulnerability?.class || 'Not assessed'}</strong><small>{sample.vulnerability?.normalized ?? '—'} normalized index</small></div></div>
    </div>
    <section className="panel"><h2>Sample metadata</h2><div className="detail-grid">{[['Source',sample.waterSourceType],['Latitude',sample.latitude],['Longitude',sample.longitude],['Collector',sample.collector],['Notes',sample.notes]].map(([label,value])=><div key={label}><small>{label}</small><p>{value ?? '—'}</p></div>)}</div></section>
    <section className="panel"><h2>Parameter results and guideline checks</h2><div className="table-wrap"><table><thead><tr><th>Parameter</th><th>Entered result</th><th>Canonical result</th><th>WHO</th><th>SON</th></tr></thead><tbody>{Object.entries(sample.parameters || {}).map(([key,entry])=><tr key={key}><td>{PARAMETER_REGISTRY[key]?.name || key}</td><td>{entry.value} {entry.unit}</td><td>{entry.canonical} {entry.canonicalUnit}</td><td>{check(key,entry.canonical,'who')}</td><td>{check(key,entry.canonical,'son')}</td></tr>)}</tbody></table></div><p className="muted">Guideline checks use the saved overrides where present. “Within configured range” is not a declaration that the water is safe to drink.</p></section>
    <section className="panel"><h2>Derived hydrochemical indicators</h2><div className="detail-grid">{Object.entries(sample.derived || {}).map(([key,value])=><div key={key}><small>{key.replaceAll(/([A-Z])/g,' $1')}</small><p>{typeof value === 'boolean' ? (value ? 'Yes' : 'No') : value ?? '—'}</p></div>)}</div></section>
    <section className="panel"><h2>WQI diagnostics</h2><p>Method: {sample.wqi?.method || 'Not recorded'}</p>{['who','son'].map(standard=><div key={standard}><h3>{standard.toUpperCase()} — F1 {sample.wqi?.[standard]?.F1 ?? '—'} · F2 {sample.wqi?.[standard]?.F2 ?? '—'} · F3 {sample.wqi?.[standard]?.F3 ?? '—'}</h3><p>{sample.wqi?.[standard]?.failedTests ?? 0} failed tests of {sample.wqi?.[standard]?.tests ?? 0}</p>{(sample.wqi?.[standard]?.failures || []).map(failure=><p className="warn" key={failure.id}>{failure.name}: {failure.value} outside configured objective</p>)}</div>)}<p className="muted">{sample.wqi?.disclaimer}</p></section>
    {sample.vulnerability && <section className="panel"><h2>{sample.vulnerability.model} factor ratings</h2><div className="detail-grid">{Object.entries(sample.vulnerability.inputs || {}).filter(([key])=>key!=='model').map(([key,value])=><div key={key}><small>{key} rating</small><p>{value}</p></div>)}</div><p className="warn">{sample.vulnerability.calibrationWarning}</p></section>}
  </div>;
}
