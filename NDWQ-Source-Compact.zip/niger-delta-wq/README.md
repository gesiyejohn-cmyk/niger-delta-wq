# Niger Delta WQ

An offline-first React application for recording water-quality samples, reviewing configured WHO/SON guideline objectives, calculating screening indices, viewing sample locations, and exporting datasets.

## Current scope

- Sample registration and editing with coordinate and measurement validation.
- IndexedDB local storage; records remain on the device/browser where they were entered.
- CSV and Excel import, CSV and GeoJSON export.
- Configurable guideline overrides and recalculation of saved samples.
- CCME WQI calculations for configured parameter objectives.
- Derived hardness, SAR, sodium percentage, and charge-balance diagnostics.
- DRASTIC and modified DRAPSTIC weighted-rating calculations.
- Sample location map using OpenStreetMap tiles (internet required for uncached tiles).
- JSON backup and restore.
- PWA shell and Capacitor/Electron packaging configuration.

## Important scientific limitations

1. The default WHO/SON objective values are initial configuration values, not a certified regulatory dataset. Verify every value, unit, parameter applicability, and edition against the official standard adopted by your study or regulator before scientific or compliance reporting. Use Settings to adjust values.
2. CCME WQI is only as representative as the objectives and parameters configured. It is a screening index; it does not establish that water is potable. Microbiological, radiological, and other required analyses may be absent.
3. DRASTIC/DRAPSTIC outputs depend on locally justified factor ratings, weights, and class thresholds. Current class thresholds are provisional and must be calibrated and validated for the study area. Pipeline proximity is a modified DRAPSTIC factor in this app.
4. Charge balance error is calculated only when all major ions, including carbonate, are entered. Missing ions are not silently treated as zero.
5. The sync queue is local scaffolding only. There is no configured cloud server or multi-device synchronization service.
6. Map tiles are provided by OpenStreetMap's public tile service. Follow its usage policy; the map is not guaranteed offline and should not be bulk-cached without an appropriate provider/policy.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm test
npm run dev
```

Open the local address printed by Vite. The app uses hash-based navigation so routes work when hosted on static file servers and in the Electron desktop wrapper.

## Production web build

```bash
npm run build
npm run preview
```

The deployable static site is written to `dist/`. Upload the contents of `dist/` to a static hosting provider that serves `index.html` and the files in `public/`. HTTPS is required for service workers and PWA installation in normal browser use (localhost is an exception).

## Android APK

Requires Android Studio/Android SDK, Java 21, and Node.js.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

Debug APK output: `android/app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, configure a signing key and use Android Gradle's release signing configuration. Do not distribute an unsigned debug APK as a production release.

## Windows installer

Build on Windows (or a properly configured Windows CI runner):

```powershell
npm install
npm run build
npx electron-builder --win nsis
```

Installer output: `release/`. Code signing is not configured; Windows SmartScreen may display an unknown-publisher warning.

## Data safety

All sample records and guideline settings are stored locally in the browser/device IndexedDB database. They are not automatically uploaded. Export a JSON backup regularly and keep a copy outside the device. Clearing browser/app data can delete local records. A backup from one browser/device must be restored manually on another.

## Testing

```bash
npm test
```

The automated tests cover selected unit conversions, WQI behavior, derived calculations, and DRASTIC completeness. They do not replace independent validation against certified laboratory datasets and published calculation examples.

## Deployment note

For a browser-accessible public URL, deploy `dist/` to an HTTPS static host (for example, a static-site service). The source ZIP is not itself a live website. No hosting account or domain has been connected by this project build.
